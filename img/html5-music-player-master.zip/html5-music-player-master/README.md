html5-music-player
==================

[在线演示DEMO](http://tivonjj.github.io/html5-music-player/)

> 只实现了移动端touch事件，请使用移动端或chrome打开调试器模拟移动设备，界面左右滑动切换列表、歌词、封面界面

html5 music player demo

HTML5 音乐播放器演示应用，

- 在线歌曲列表
- 歌词滚动显示
- 封面旋转显示
- 曲目控制
- 进度条拖动